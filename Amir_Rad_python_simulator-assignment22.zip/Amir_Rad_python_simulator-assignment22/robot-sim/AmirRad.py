from __future__ import print_function

import time
import random
from sr.robot import *

"""
Exercise 2 python script

Put the main code after the definition of the functions. The code should make the robot grab the closest marker (token)
Steps to be performed:
1 - call the function find_token() to retrieve the distance and the angle between the robot and the closest marker
2 - drive the robot towards the marker. If the distance between the robot and the marker is less than d_th
     meters, the robot can grab the marker, by using the method grab() of the class Robot. Otherwise, the 
     robot should be driven toward the token. The robot is a non-holonomic robot, so you should control the 
     angle, by calling the method turn, if rot_y is greater then a_th or lower then -a_th (check the sign!).
     On the contrary, if -a_th < rot_y < a_th, you can use the method drive to move the robot forward.
3 - after you grab the marker, you can exit the program (function exit()).

   When done, run with:
	$ python run.py solutions/exercise2_solution.py
"""


a_th = 2.0

""" float: Threshold for the control of the linear distance"""

d_th = 0.6
""" float: Threshold for the control of the orientation"""

R = Robot()
""" instance of the class Robot"""


# The Robot Status Upadte...    Real-time  --------------
robot_status=0;

#  ------------  Random amount generator 1
ran1 = random.randint(1,7)

#  ------------  Random amount generator 2
ran2 = random.randint(-2,3)

def drive(speed, seconds):
    """
    Function for setting a linear velocity
    
    Args: speed (int): the speed of the wheels
	  seconds (int): the time interval
    """
    speed=speed*4
    R.motors[0].m0.power = speed
    R.motors[0].m1.power = speed
    time.sleep(seconds)
    R.motors[0].m0.power = 0
    R.motors[0].m1.power = 0

def turn(speed, seconds):
    """
    Function for setting an angular velocity
    
    Args: speed (int): the speed of the wheels
	  seconds (int): the time interval
    """
    R.motors[0].m0.power = speed
    R.motors[0].m1.power = -speed
    time.sleep(seconds)
    R.motors[0].m0.power = 0
    R.motors[0].m1.power = 0


def find_silver():
	dist =100
	for token in R.see():
		if token.dist < dist and token.info.marker_type is MARKER_TOKEN_SILVER: # found a silver token
			print("search for a silver box")
			dist=token.dist
			rot_y=token.rot_y
	if dist==100:
		return -1, -1
        else:
   		return dist, rot_y
   		
def find_gold():
	dist =100
	for token in R.see():
		if token.dist < dist and token.info.marker_type is MARKER_TOKEN_GOLD: # found a gold token
			print("serarch for a golden box")
			dist=token.dist
			rot_y=token.rot_y
	if dist==100:
		return -1, -1
        else:
   		return dist, rot_y

# +++ Add my Function +++ 
   		
def action_target(obj_dis,obj_rot):
    if obj_dis <0.4:
    	print("Found it!")
        test=R.grab() # if the robot is close to the token, we grab it.
        print(test)
	print("Gotcha!") 
	robot_status = 1;
    elif -a_th<= obj_rot <= a_th: # if the robot is aligned with the token, we go forward
    	print("Ah, here we are!.")
	drive(10, 0.5)
	robot_status = 0;
    elif obj_rot < -a_th: # if the robot is not aligned with the token, we move it on the left or on the right
	print("Left a bit...")
	turn(-2, 0.5)
	robot_status = 0;
    elif obj_rot > a_th:
	print("Right a bit...")
	turn(+2, 0.5)
	robot_status = 0;
       
    return robot_status
	

#==========================================================================================================	
	

while 1:
	
	dist_silver,rot_silver = find_silver() # I look for silver markers
	print("Silver Box ...")
	
	if dist_silver == -1:	
		drive(-10, 0.5) 
		turn(4 + ran1, 3)
		print("feedback 1")
	if robot_status == 0:
		robot_status = action_target(dist_silver,rot_silver)  
		print(robot_status)
		print("feedback 2")
	elif robot_status == 1:
		while 1:
			dist_gold,rot_gold = find_gold()
			if dist_gold == -1:
				print("the robot did not fiund any gold box")
				drive(8 + ran2, 5) 
				turn(+10,2)

			action_target(dist_gold,rot_gold)
			if dist_gold <d_th:
				print("Ok, lets relearse it")
				R.release()
				drive(-10, 1) 
				turn(7 + ran1,3)
				robot_status = 0
			break
				
		      

       
       

	
